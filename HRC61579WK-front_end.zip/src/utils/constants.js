export const APISERVER_URL = 'http://localhost:8080/';
export const APIPOJECT_NAME = 'HRC_B2B';
export const MLSERVERURL = 'http://localhost:5000/';