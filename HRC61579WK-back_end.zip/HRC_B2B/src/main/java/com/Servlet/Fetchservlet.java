package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Crud;
import com.Pojo.winter_internship;
import com.google.gson.Gson;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 * Servlet implementation class Fetchservlet
 */
@WebServlet("/Fetchservlet")
public class Fetchservlet extends HttpServlet {
	private static Connection conn = null;
	private static PreparedStatement stmt = null;
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Fetchservlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//int page = Integer.parseInt(request.getParameter("page"));
		//int records_per_page = 50;	
		
		
		String business_code,doc_id,invoice_currency,document_type,area_business,cust_payment_terms,aging_bucket;
		Integer sl_no,cust_number,posting_id,invoice_id,isOpen,is_deleted;
		Date posting_date,buisness_year,document_create_date,document_create_date1,due_in_date,baseline_create_date,clear_date;
		Double total_open_amount;
		
		try {
			ArrayList<winter_internship> data = new ArrayList<winter_internship>();
			conn = Crud.getConnection();
			/*
			stmt = conn.prepareStatement(
					"SELECT * FROM winter_internship"+(page-1)*records_per_page+","+records_per_page);*/
			stmt = conn.prepareStatement(
					"SELECT * FROM winter_internship");
			ResultSet result = stmt.executeQuery();			
			System.out.println(stmt);
					
			while(result.next()) {
				winter_internship pojo = new winter_internship();
				
				sl_no=result.getInt("sl_no");
				cust_number= result.getInt("cust_number");
				posting_id =result.getInt("posting_id");
				invoice_id =result.getInt("invoice_id");
				isOpen =result.getInt("isOpen");
				is_deleted= result.getInt("is_deleted");
				
				business_code = result.getString("business_code");
				doc_id = result.getString("doc_id");
				invoice_currency = result.getString("invoice_currency");
				document_type = result.getString("document_type");
				area_business = result.getString("area_business");
				cust_payment_terms = result.getString("cust_payment_terms");
				aging_bucket = result.getString("aging_bucket");
				
				clear_date = result.getDate("clear_date");
				
				buisness_year = result.getDate("buisness_year");
				posting_date = result.getDate("posting_date");
				document_create_date = result.getDate("document_create_date");
				document_create_date1 = result.getDate("document_create_date1");
				due_in_date = result.getDate("due_in_date");
				baseline_create_date = result.getDate("baseline_create_date");
				
				total_open_amount = result.getDouble("total_open_amount");
				
				//=========================================================
				
				pojo.setSl_no(sl_no);
				pojo.setCust_number(cust_number);
				pojo.setPosting_id(posting_id);
				pojo.setInvoice_id(invoice_id);
				pojo.setIsOpen(isOpen);
				pojo.setIs_deleted(is_deleted);
				pojo.setBusiness_code(business_code);
				pojo.setDoc_id(doc_id);
				pojo.setInvoice_currency(invoice_currency);
				pojo.setDocument_type(document_type);
				pojo.setArea_business(area_business);
				pojo.setCust_payment_terms(cust_payment_terms);
				pojo.setAging_bucket(aging_bucket);
				
				pojo.setClear_date(clear_date);
				
				pojo.setBuisness_year(buisness_year);
				pojo.setPosting_date(posting_date);
				pojo.setDocument_create_date(document_create_date);
				pojo.setDocument_create_date1(document_create_date1);
				pojo.setDue_in_date(due_in_date);
				pojo.setBaseline_create_date(baseline_create_date);
				pojo.setTotal_open_amount(total_open_amount);
				
				data.add(pojo);
			}
			Gson gson = new Gson();
			String resData = gson.toJson(data);
			response.setHeader("Access-Control-Allow-Origin","*");
			PrintWriter out = response.getWriter();
			//response.getWriter().append(resData);
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8"); 
			out.print(resData);
			out.flush();
			
			result.close();
			stmt.close();
			for(winter_internship winterIntern: data) {
				System.out.println(winterIntern.toString());
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
