package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Crud;
import com.Pojo.AnalyticsPojo;
import com.google.gson.Gson;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * Servlet implementation class Analytics
 */
@WebServlet("/Analytics")
public class Analytics extends HttpServlet {
	private static Connection conn = null;
	private static PreparedStatement stmt1 = null;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Analytics() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String baseLineDateStart = request.getParameter("baseLineDateStart");
		String baseLineDateEnd = request.getParameter("baseLineDateEnd");
		String clearDateStart = request.getParameter("clearDateStart");
		String clearDateEnd = request.getParameter("clearDateEnd");
		String dueDateStart = request.getParameter("dueDateStart");
		String dueDateEnd = request.getParameter("dueDateEnd");
		String invoiceCurrency = request.getParameter("invoiceCurrency");
		
		String business_code;
		Integer cust_number;
		Double total_open_amount;
		
		if(!invoiceCurrency.isEmpty()) {
			try {
				ArrayList<AnalyticsPojo> data = new ArrayList<AnalyticsPojo>(); 
				conn = Crud.getConnection();
				
				stmt1 = conn.prepareStatement(
						"SELECT business_code,COUNT(*) as Count,SUM(total_open_amount) as Sum FROM winter_internship "
						+ "WHERE baseline_create_date >= '"+baseLineDateStart+"' AND baseline_create_date <= '"+baseLineDateEnd+"' "
						+ "AND clear_date >= '"+clearDateStart+"' AND clear_date <= '"+clearDateEnd+"' AND "
						+ "due_in_date >= '"+dueDateStart+"' AND due_in_date <= '"+dueDateEnd+"' AND invoice_currency = '"+invoiceCurrency+"'"
						+ "GROUP BY business_code");
				
	
				ResultSet result1 = stmt1.executeQuery();			
				System.out.println(stmt1);
				
				while(result1.next()) {
					AnalyticsPojo pojo = new AnalyticsPojo();
					
					business_code=result1.getString("business_code");
					cust_number=result1.getInt("Count");
					total_open_amount=result1.getDouble("Sum");
					
					pojo.setBusiness_code(business_code);
					pojo.setCust_number(cust_number);
					pojo.setTotal_open_amount(total_open_amount);
					
					data.add(pojo);
				}
				
				Gson gson = new Gson();
				String resData = gson.toJson(data);
				response.setHeader("Access-Control-Allow-Origin","*");
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8"); 
				out.print(resData);
				out.flush();
				result1.close();
				stmt1.close();
				conn.close();
			}
			catch(Exception e) {
				e.printStackTrace();
				System.out.println("exception occur");
			}
		}
		
		else{
			try {
				ArrayList<AnalyticsPojo> data = new ArrayList<AnalyticsPojo>(); 
				conn = Crud.getConnection();
				
				stmt1 = conn.prepareStatement(
						"SELECT business_code,COUNT(*) as Count,SUM(total_open_amount) as Sum FROM winter_internship "
						+ "WHERE baseline_create_date >= '"+baseLineDateStart+"' AND baseline_create_date <= '"+baseLineDateEnd+"' "
						+ "AND clear_date >= '"+clearDateStart+"' AND clear_date <= '"+clearDateEnd+"' AND "
						+ "due_in_date >= '"+dueDateStart+"' AND due_in_date <= '"+dueDateEnd+"' GROUP BY business_code");
				
	
				ResultSet result1 = stmt1.executeQuery();			
				System.out.println(stmt1);
				
				while(result1.next()) {
					AnalyticsPojo pojo = new AnalyticsPojo();
					
					business_code=result1.getString("business_code");
					cust_number=result1.getInt("Count");
					total_open_amount=result1.getDouble("Sum");
					
					pojo.setBusiness_code(business_code);
					pojo.setCust_number(cust_number);
					pojo.setTotal_open_amount(total_open_amount);
					
					data.add(pojo);
				}
				
				Gson gson = new Gson();
				String resData = gson.toJson(data);
				response.setHeader("Access-Control-Allow-Origin","*");
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8"); 
				out.print(resData);
				out.flush();
				result1.close();
				stmt1.close();
				conn.close();
			}
			catch(Exception e) {
				e.printStackTrace();
				System.out.println("exception occur");
			}			
		}	
	}
}
